// Определение версии кэша
var cacheName = 'my-cache-v1';

// Ресурсы для кэширования
var cacheResources = [
  'main.php',
  // Добавьте сюда другие ресурсы, которые вы хотите кэшировать
];

// Устанавливаем Service Worker
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.addAll(cacheResources);
    })
  );
});

// Активируем Service Worker и удаляем устаревшие кэши
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(existingCacheName) {
          if (existingCacheName !== cacheName) {
            return caches.delete(existingCacheName);
          }
        })
      );
    })
  );
});

// Перехватываем запросы клиента
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(cachedResponse) {
      return (
        cachedResponse ||
        fetch(event.request).then(function(networkResponse) {
          caches.open(cacheName).then(function(cache) {
            cache.put(event.request, networkResponse.clone()); // Обновляем кэш с сервера
          });
          return networkResponse.clone();
        })
      );
    })
  );
});
