<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="manifest.json">
    <title>PWA Application</title>
    <style>
        /* CSS для стилизации страницы */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px;
            text-align: center;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #444;
        }
        nav a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
        }
        nav a:hover {
            background-color: #555;
        }
        #log {
            margin: 20px;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <header>
        <h1>PWA Application</h1>
        <h2>Нефёдов Дмитрий Андреевич</h2>
    </header>
    <nav>
        <a href="#">Home</a>
        <a href="#">Item1</a>
        <a href="#">Item2</a>
        <a href="#">About</a>
    </nav>
    <button id="installbutton" style="display: none;">Установить</button>

    <div id="log"></div>

    <script>
        if ('serviceWorker' in navigator) {
            // Регистрация Service Worker
            navigator.serviceWorker.register('service-worker.js').then(function(registration) {
                console.log('Service Worker registered with scope:', registration.scope);
                document.getElementById('log').textContent += 'Service Worker registered with scope: ' + registration.scope + '\n';
            }).catch(function(error) {
                console.error('Service Worker registration failed:', error);
                document.getElementById('log').textContent += 'Service Worker registration failed: ' + error + '\n';
            });

            // Обработка события установки Service Worker
            navigator.serviceWorker.addEventListener('controllerchange', function() {
                console.log('Service Worker installed and activated.');
                document.getElementById('log').textContent += 'Service Worker installed and activated.\n';
                document.getElementById('installbutton').style.display = 'none';
            });

            // Отслеживание сообщений от Service Worker
            navigator.serviceWorker.addEventListener('message', function(event) {
                console.log('Message from Service Worker:', event.data);
                document.getElementById('log').textContent += 'Message from Service Worker: ' + event.data + '\n';
            });

            // Проверка, можно ли установить PWA на устройство
            window.addEventListener('beforeinstallprompt', function(event) {
                event.preventDefault(); // Предотвратить отображение браузерного диалога
                document.getElementById('installbutton').style.display = 'block';
                document.getElementById('installbutton').addEventListener('click', function() {
                    event.prompt(); // Отображение диалога установки
                    event.userChoice.then(function(choiceResult) {
                        if (choiceResult.outcome === 'accepted') {
                            console.log('User accepted the install prompt.');
                            document.getElementById('log').textContent += 'User accepted the install prompt.\n';
                            document.getElementById('installbutton').style.display = 'none';
                        } else {
                            console.log('User dismissed the install prompt.');
                            document.getElementById('log').textContent += 'User dismissed the install prompt.\n';
                        }
                    });
                });
            });
        }
    </script>
</body>
</html>
