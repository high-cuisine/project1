document.addEventListener('DOMContentLoaded', function() {
    const imageUrlInput = document.getElementById('imageUrlInput');
    const showButton = document.getElementById('showButton');
    const showAndCacheButton = document.getElementById('showAndCacheButton');
    const displayedImage = document.getElementById('displayedImage');

    // Обработчик для кнопки "Show"
    showButton.addEventListener('click', function() {
        const imageUrl = imageUrlInput.value;
        if (imageUrl) {
            displayedImage.src = imageUrl;
        }
    });

    // Обработчик для кнопки "Show and Cache"
    showAndCacheButton.addEventListener('click', function() {
        const imageUrl = imageUrlInput.value;
        if (imageUrl) {
            // Кэширование изображения
            caches.open('image-cache').then(function(cache) {
                cache.add(imageUrl);
            }).catch(function(error) {
                console.error('Failed to cache image:', error);
            });

            // Отображение изображения
            displayedImage.src = imageUrl;
        }
    });

    // Проверка на наличие Service Worker
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('service-worker.js').then(function(registration) {
            console.log('Service Worker registered with scope:', registration.scope);
        }).catch(function(error) {
            console.error('Service Worker registration failed:', error);
        });
    }

    // Проверка на наличие кэшированного изображения при загрузке
    caches.match('2.jpg').then(function(response) {
        if (response) {
            displayedImage.src = '2.jpg';
        }
    });
});
