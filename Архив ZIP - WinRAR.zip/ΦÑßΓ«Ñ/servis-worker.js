// Объявление переменной для кэшированных ресурсов
const CACHE_NAME = 'my-cache-v1';
const CACHE_FILES = [
  '/',
  '/index.html',
  '/main.js',
  '/manifest.json',
  '/5.png',
  '/2.jpg' // Замените на путь к вашей подмене
];

// Установка Service Worker
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      return cache.addAll(CACHE_FILES);
    })
  );
});

// Активация Service Worker
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.map(function(cacheName) {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Обработка запросов и кэширование
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(response) {
      return response || fetch(event.request).then(function(response) {
        // Кэширование новых ресурсов, если они не кэшированы
        if (event.request.method === 'GET' && !event.request.url.includes('chrome-extension://')) {
          caches.open(CACHE_NAME).then(function(cache) {
            cache.put(event.request, response.clone());
          });
        }
        return response;
      });
    }).catch(function() {
      // Отображение подмены, если ресурс не найден
      return caches.match('/2.jpg');
    })
  );
});

// Удаление старых кэшей
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.filter(function(cacheName) {
          return cacheName !== CACHE_NAME;
        }).map(function(cacheName) {
          return caches.delete(cacheName);
        })
      );
    })
  );
});
