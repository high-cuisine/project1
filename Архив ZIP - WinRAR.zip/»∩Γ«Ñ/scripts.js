// Ваш JavaScript код для загрузки и отображения эмодзи
document.addEventListener('DOMContentLoaded', function () {
    const emojiContainer = document.getElementById('emoji');

    // Функция для загрузки эмодзи с сервера
    function loadEmojis() {
        fetch('https://api.github.com/emojis')
            .then(response => response.json())
            .then(emojis => {
                // Создаем и добавляем изображения эмодзи в контейнер
                for (const emojiName in emojis) {
                    const emojiImg = document.createElement('img');
                    emojiImg.src = emojis[emojiName];
                    emojiImg.alt = emojiName;
                    emojiContainer.appendChild(emojiImg);
                }
            })
            .catch(error => console.error('Ошибка при загрузке эмодзи:', error));
    }

    loadEmojis();
});
