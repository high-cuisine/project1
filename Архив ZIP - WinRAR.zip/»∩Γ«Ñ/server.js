const express = require('express');
const https = require('https');
const fs = require('fs');

const app = express();

// Загрузка статических файлов, например, index.html и других ресурсов
app.use(express.static(__dirname));

// Создание HTTPS-сервера с самоподписанным сертификатом
const options = {
    key: fs.readFileSync('server.key'),
    cert: fs.readFileSync('server.crt')
};

const server = https.createServer(options, app);

const port = process.env.PORT || 3000;

server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
