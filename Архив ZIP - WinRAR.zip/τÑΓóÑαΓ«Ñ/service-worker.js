// Объявление переменной logMessages
let logMessages = [];

// Регистрация служебного работника
self.addEventListener('install', function(event) {
    event.waitUntil(
        caches.open('my-cache').then(function(cache) {
            return cache.addAll([
                '/',
                '/index.html',
                '/css/styles.css',
                '/js/main.js',
                '/manifest.json',
                // Добавьте сюда другие ресурсы, которые вы хотите кэшировать
            ]).catch(function(error) {
                console.error('Failed to cache files:', error);
            });
        })
    );
});

self.addEventListener('activate', function(event) {
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName !== 'my-cache') {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

self.addEventListener('fetch', function(event) {
    event.respondWith(
        caches.match(event.request).then(function(response) {
            return response || fetch(event.request);
        })
    );
});

self.addEventListener('message', function(event) {
    if (event.data === 'getLog') {
        event.source.postMessage(logMessages);
    }
});

// Обработка логов в SW
function logToSW(message) {
    logMessages.push(message);
    console.log('From Service Worker Thread:', message);
}
