<?php
// Функция для создания и вывода splash-screen с изображением и текстом на веб-странице
function createAndDisplaySplashScreen($width, $height, $topImagePath, $bottomImagePath, $text) {
    $image = imagecreatetruecolor($width, $height);

    // Загружаем изображение для верхней части splash-screen
    $topImage = imagecreatefrompng($topImagePath);

    // Загружаем изображение для нижней части splash-screen
    $bottomImage = imagecreatefrompng($bottomImagePath);

    // Налагаем верхнее изображение на верхнюю половину экрана
    $topWidth = imagesx($topImage);
    $topHeight = imagesy($topImage);
    imagecopyresampled($image, $topImage, 0, 0, 0, 0, $width, $height / 2, $topWidth, $topHeight);

    // Поворачиваем нижнее изображение на 45 градусов
    $bottomImage = imagerotate($bottomImage, 45, 0);

    // Налагаем нижнее изображение на нижнюю часть экрана
    $bottomWidth = imagesx($bottomImage);
    $bottomHeight = imagesy($bottomImage);
    imagecopyresampled($image, $bottomImage, 0, $height / 2, 0, 0, $width, $height / 2, $bottomWidth, $bottomHeight);

    // Создаем цвет для текста
    $textColor = imagecolorallocate($image, 0, 0, 0);

    // Поворачиваем текст на 45 градусов
    $angle = 45;
    $textX = $width / 4;
    $textY = $height / 2;
    imagettftext($image, 20, $angle, $textX, $textY, $textColor, 'arial.ttf', $text);

    // Выводим splash-screen на веб-страницу
    header('Content-Type: image/png');
    imagepng($image);
    imagedestroy($image);
}

// Путь к изображению для верхней части splash-screen
$topImagePath = '5.png';

// Путь к изображению для нижней части splash-screen
$bottomImagePath = '5.png';

// Текст для нижней части splash-screen
$text = "Нефедов Дмитрий Андреевич";

// Разрешение экрана вашего устройства (например, для iPhone XR)
$width = 828;
$height = 1792;

createAndDisplaySplashScreen($width, $height, $topImagePath, $bottomImagePath, $text);
?>
