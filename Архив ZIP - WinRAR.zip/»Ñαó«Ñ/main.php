<?php
// Функция для создания и сохранения иконки
function createIcon($size, $imagePath) {
    $image = imagecreatetruecolor($size, $size);
    $bgColor = imagecolorallocate($image, 255, 255, 255); // Белый фон

    // Заполняем фон белым цветом
    imagefill($image, 0, 0, $bgColor);

    // Загружаем изображение
    $overlayImage = imagecreatefrompng($imagePath);

    // Получаем размеры изображения
    $imageWidth = imagesx($overlayImage);
    $imageHeight = imagesy($overlayImage);

    // Изменяем размер изображения, чтобы оно вписалось в иконку
    $newWidth = $newHeight = $size;
    if ($imageWidth > $imageHeight) {
        $newHeight = ($size / $imageWidth) * $imageHeight;
    } else {
        $newWidth = ($size / $imageHeight) * $imageWidth;
    }

    // Налагаем измененное изображение
    imagecopyresampled($image, $overlayImage, ($size - $newWidth) / 2, ($size - $newHeight) / 2, 0, 0, $newWidth, $newHeight, $imageWidth, $imageHeight);

    // Сохраняем иконку
    $filename = "icon_$size.png";
    imagepng($image, $filename);
    imagedestroy($image);

    return $filename;
}

// Путь к изображению, которое нужно наложить на иконку
$imagePath = 'C:\Users\user\Desktop\задания\первое\5.png'; // Замените на путь к вашему изображению

// Размеры иконок, которые вы хотите создать
$sizes = [32, 64, 96, 128, 168, 192, 256, 512];

foreach ($sizes as $size) {
    createIcon($size, $imagePath);
}

echo "Иконки успешно созданы и сохранены.";
?>
