'use strict';  // Строгий режим JavaScript для более безопасной работы

const express = require('express');  // Подключаем библиотеку Express.js
const bodyParser = require('body-parser');  // Подключаем библиотеку для обработки JSON-запросов
const fetch = require('node-fetch');  // Подключаем библиотеку для выполнения HTTP-запросов
const fs = require('fs');  // Подключаем библиотеку для работы с файловой системой
const path = require('path');  // Подключаем библиотеку для работы с путями к файлам

const app = express();  // Создаем экземпляр сервера Express
const PORT = process.env.PORT || 3005;  // Устанавливаем порт сервера (либо берем из переменной окружения, либо используем 3005)

app.use(bodyParser.json());  // Используем bodyParser для обработки JSON-запросов

const BASE_URL = "http://exam-2023-1-api.std-900.ist.mospolytech.ru/";  // Устанавливаем базовый URL удаленного API
const API_KEY = "88c000e0-6fbb-4799-bd75-6b9cac9fc116";  // Устанавливаем API ключ

// Функция для преобразования объекта в строку, представляющую его имя
const varToString = varObj => Object.keys(varObj)[0].toLowerCase();

// Функция для преобразования данных в форму, пригодную для отправки через POST-запрос
const dataShield = async (data) => {
  let formBody = [];
  for (let property in data) {
    let encodedKey = encodeURIComponent(property);
    let encodedValue = encodeURIComponent(data[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");
  return formBody;
};

// Функция для получения данных о маршрутах из удаленного API
const getRoutes = async () => {
  try {
    let endpoint = new URL("api/routes", BASE_URL);
    endpoint.searchParams.set(varToString({ API_KEY }), API_KEY);
    let response = await fetch(endpoint);
    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status}`);
    }
    let data = await response.json();
    if ("error" in data) {
      throw new Error(data.error);
    } else {
      console.log("Данные о маршрутах успешно получены");
      return data;
    }
  } catch (error) {
    console.error("Ошибка при получении данных о маршрутах:", error.message);
    throw error;
  }
};

// Функция для получения данных о гидах для определенного маршрута
const getGuides = async (routeId) => {
  try {
    let endpoint = new URL(`api/routes/${routeId}/guides`, BASE_URL);
    endpoint.searchParams.set(varToString({ API_KEY }), API_KEY);
    let response = await fetch(endpoint);
    if (!response.ok) {
      throw new Error(`Ошибка HTTP: ${response.status}`);
    }
    let data = await response.json();
    if ("error" in data) {
      throw new Error(data.error);
    } else {
      console.log("Данные о гидах успешно получены");
      return data;
    }
  } catch (error) {
    console.error("Ошибка при получении данных о гидах:", error.message);
    throw error;
  }
};

// Функция для сохранения данных в файл data.json
const saveDataToFile = async (data) => {
  try {
    const filePath = path.join(__dirname, 'data.json'); // Путь к файлу

    // Для каждого маршрута, получите данные о гидах и добавьте их к маршруту
    for (let route of data) {
      const guidesData = await getGuides(route.id); // Получить данные о гидах для маршрута
      route.guides = guidesData; // Добавить данные о гидах к маршруту
    }

    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');  // Сохраняем данные в файл data.json
    console.log("Данные успешно сохранены в data.json");
  } catch (error) {
    console.error("Ошибка при сохранении данных:", error.message);
    throw error;
  }
};

// Роут для получения данных и сохранения их в файл
app.get('/get-data', async (req, res) => {
  try {
    let data = await getRoutes();  // Получаем данные о маршрутах
    saveDataToFile(data);  // Сохраняем данные в файл
    res.json({ message: "Данные успешно получены и сохранены" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Произошла ошибка при получении и сохранении данных" });
  }
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
});
